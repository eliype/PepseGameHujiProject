package pepse.world.AvatarJumpObserver;

/**
 * interface for all classes that interact with avatar jump
 * @author Eliyahu & Rom
 */
public interface AvatarJumpObserver {
	public void update();
}
