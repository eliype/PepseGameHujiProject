package pepse.world.AvatarJumpObserver;

public interface AvatarJumpObserver {
	public void update();
}
